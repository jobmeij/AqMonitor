选择 `ESP32 Dev Module`

Select `ESP32 Dev Module`